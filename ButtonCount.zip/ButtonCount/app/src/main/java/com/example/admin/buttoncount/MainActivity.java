package com.example.admin.buttoncount;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button countButton, decreaseButton,resetButton;
    TextView displayTextView;
    int numberOfCount=0;

    SharedPreferences mSharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        countButton =(Button)findViewById(R.id.buttonCount);
        countButton.setOnClickListener(this);

        decreaseButton=(Button)findViewById(R.id.buttonDecrease);
        decreaseButton.setOnClickListener(this);

        resetButton=(Button)findViewById(R.id.buttonDecrease);
        resetButton.setOnClickListener(this);

        displayTextView=(TextView)findViewById(R.id.textViewDisplay);

        mSharedPreferences = getPreferences(Context.MODE_PRIVATE);

    }

    @Override
    public void onPause(){
        super.onPause();
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putInt("cNumber",numberOfCount);
        editor.commit();
        Toast.makeText(this, "Paused",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onStart(){
        super.onStart();

        mSharedPreferences = getPreferences(Context.MODE_PRIVATE);
        numberOfCount=mSharedPreferences.getInt("cNumber", 0);

        displayTextView.setText(numberOfCount+"");
    }
    @Override
    public void onClick(View v) {

        if(v.equals(countButton)){
            displayTextView.setText(Integer.toString(Count()));}
         else if (v.equals(decreaseButton)){
            displayTextView.setText(Integer.toString(Decrease()));
        }else {
            displayTextView.setText(0);
            numberOfCount=0;
        }
        /* The other method for if else statement
        int id=v.getId();

        if (id==R.id.buttonCount){
            displayTextView.setText(Integer.toString(Count()));
        }else if(id==R.id.buttonDecrease){
            displayTextView.setText(Integer.toString(Decrease()));
        }
        */
    }
    public int Count(){

        numberOfCount++;
        //NumberOfCount=numberOfCount+1;

        return numberOfCount;

    }
    public int Decrease(){
        numberOfCount--;

        return numberOfCount;
    }
    public int Reset(){

        displayTextView.setText("0");
        numberOfCount=0;

        return  numberOfCount;

    }
}
